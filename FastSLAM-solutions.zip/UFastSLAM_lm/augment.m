function augment(particle,z,R,idf)

% add new features to state
for i=1:size(z,2)
    add_one_z(particle, z(:,i),R,idf);
end

end

%
%

function add_one_z(particle,z,R,idf)
for i = 1:length(idf),
    xf_aug = [particle.xf(:,i) ; z];
    Pf_aug = blkdiag(particle.Pf(:,:,i), R);
    [xf_aug, Pf_aug] = unscented_transform(@augment_model, [], xf_aug,Pf_aug);
%     particle.Pf(:,:,i)
end

% particle.xf(:,i) = 


end



%
%

function x = augment_model(x);
phi = x(3, :);
r = x(end-1, :);
b = x(end, :);
s = sin(phi + b); 
c = cos(phi + b);

x(end-1, :) = x(1,:) + r.*c;
x(end, :)   = x(2,:) + r.*s;
end
