function w= compute_weight_re(particle, z, idf, R)

xv0= particle.xv;
Pv0= particle.Pv;

% compute sample weight: w = w * p(z|xk) p(xk|xk-1) / proposal
like = likelihood_given_xv(particle, z,idf, R);
prior = gauss_evaluate(delta_xv(xv0,xvs), Pv0);
prop =  gauss_evaluate(delta_xv(xv, xvs), Pv);
w = particle.w * like * prior / prop;

%
%

function w = likelihood_given_xv(particle, z,idf, R)
% For FastSLAM, p(z|xv) requires the map part to be marginalised from p(z|xv,m)
w = 1;
for i=1:length(idf)
    [zp,Hv,Hf,Sf]= compute_jacobians(particle, idf(i), R);
    v= z(:,i)-zp; 
    v(2)= pi_to_pi(v(2));

    w = w * gauss_evaluate(v,Sf);
end

%
%

function dx = delta_xv(xv1, xv2)
% Compute innovation between two xv estimates, normalising the heading component
dx = xv1 - xv2;
dx(3,:) = pi_to_pi(dx(3,:));
