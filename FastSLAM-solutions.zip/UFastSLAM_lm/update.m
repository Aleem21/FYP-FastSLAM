function particle = update(particle,z,R,idf)
%UPDATE Summary of this function goes here
%   Detailed explanation goes here
xf = particle.xf;
Pf = particle.Pf;

for i=1:length(idf)
    [xv_u,Pv_u] = unscented_update(@observe_model, @observediff, xf,Pf, z(:,i),R, idf(i));
    particle.xf = xv_u;
    particle.Pf = Pv_u;
end

end

%

function dz = observediff(z1, z2)
dz = z1-z2;
dz(2,:) = pi_to_pi(dz(2,:));


end

