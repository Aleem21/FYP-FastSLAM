function [z,idf]= get_observations(x, lm, idf, rmax)

[lm,idf]= get_visible_landmarks(x,lm,idf,rmax);
z= compute_range_bearing(x,lm);

%
%
%
%


    
